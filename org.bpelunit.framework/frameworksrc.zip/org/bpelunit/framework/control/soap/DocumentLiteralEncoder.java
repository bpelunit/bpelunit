/**
 * This file belongs to the BPELUnit utility and Eclipse plugin set. See enclosed
 * license file for more information.
 * 
 */
package org.bpelunit.framework.control.soap;

import java.util.Iterator;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;

import org.bpelunit.framework.control.ext.ISOAPEncoder;
import org.bpelunit.framework.control.util.BPELUnitConstants;
import org.bpelunit.framework.control.util.BPELUnitUtil;
import org.bpelunit.framework.exception.SOAPEncodingException;
import org.bpelunit.framework.model.test.data.SOAPOperationCallIdentifier;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * <p>
 * This class implements an Encoder for SOAP messages in document/literal style. The WSDL specifying
 * the target web service must be structured as specified in the WS-I Basic Profile, which has the
 * following implications for this encoder:
 * </p>
 * 
 * <p>
 * The operation which defines the message must be a document/literal operation, as defined in
 * section 5.3 of WS-I BP.
 * </p>
 * <p>
 * <ul>
 * <li>The style attribute must be "document", and the use attributes must be "literal".</li>
 * <li>The soap:body elements must have at most one part specified, or none, in which case the
 * corresponding message must only have one part specified (this is not strictly required by this
 * encoder - more parts are allowed).</li>
 * <li>The referenced parts in the messages MUST(!) be specified with the "element" attribute:
 * <i>R2204 A document-literal binding in a DESCRIPTION MUST refer, in each of its soapbind:body
 * element(s), only to wsdl:part element(s) that have been defined using the element attribute.</i></li>
 * </ul>
 * </p>
 * 
 * <p>
 * The last point is most relevant, as this allows the encoder to just copy the literal elements
 * into the SOAP Body or Fault Detail, no questions asked.
 * </p>
 * 
 * @version $Id: DocumentLiteralEncoder.java 81 2007-06-03 10:07:37Z asalnikow $
 * @author Philip Mayer
 * 
 */
public class DocumentLiteralEncoder implements ISOAPEncoder {

	public SOAPMessage construct(SOAPOperationCallIdentifier operation, Element literalElement) throws SOAPEncodingException {

		try {

			MessageFactory mFactory= BPELUnitUtil.getMessageFactoryInstance();
			SOAPFactory sFactory= SOAPFactory.newInstance();

			SOAPMessage message= mFactory.createMessage();
			SOAPBody body= message.getSOAPBody();
			SOAPElement data;
			if (operation.isFault()) {
				SOAPFault fault= body.addFault(new QName(BPELUnitConstants.SOAP_1_1_NAMESPACE, BPELUnitConstants.SOAP_FAULT_CODE_CLIENT),
						BPELUnitConstants.SOAP_FAULT_DESCRIPTION);
				data= fault.addDetail();
			} else
				data= body;

			NodeList nodes= literalElement.getChildNodes();
			for (int i= 0; i < nodes.getLength(); i++) {
				SOAPElement soapElement= sFactory.createElement((Element) nodes.item(i));
				data.addChildElement(soapElement);
			}

			return message;
		} catch (SOAPException e) {
			throw new SOAPEncodingException("A SOAPException occurred in the DocumentLiteralEncoder while encoding to operation " + operation, e);
		}
	}


	public Element deconstruct(SOAPOperationCallIdentifier operation, SOAPMessage message) throws SOAPEncodingException {

		try {
			SOAPBody body= message.getSOAPBody();
			SOAPElement data;

			if (operation.isFault()) {
				// a fault is expected
				SOAPFault fault= body.getFault();
				if (fault == null)
					throw new SOAPEncodingException("A fault was expected in operation " + this + ", but none was found in input data.");
				else
					data= body.getFault().getDetail();
			} else
				data= body;

			Element rawRoot= BPELUnitUtil.generateDummyElementNode();
			for (Iterator i= data.getChildElements(); i.hasNext();) {
				Object current= i.next();
				if (current instanceof SOAPElement) {
					SOAPElement element= (SOAPElement) current;
					rawRoot.appendChild(rawRoot.getOwnerDocument().importNode(element, true));
				}

			}
			return rawRoot;
		} catch (SOAPException e) {
			throw new SOAPEncodingException("A SOAPException occurred in the DocumentLiteralEncoder while decoding for operation " + operation);
		}
	}


}
