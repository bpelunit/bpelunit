/*
 * XML Type:  AnyElement
 * Namespace: http://www.bpelunit.org/schema/testSuite
 * Java type: org.bpelunit.framework.xml.suite.XMLAnyElement
 *
 * Automatically generated - do not modify.
 */
package org.bpelunit.framework.xml.suite.impl;
/**
 * An XML AnyElement(@http://www.bpelunit.org/schema/testSuite).
 *
 * This is a complex type.
 */
public class XMLAnyElementImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.bpelunit.framework.xml.suite.XMLAnyElement
{
    
    public XMLAnyElementImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
