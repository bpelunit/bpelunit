package org.bpelunit.framework;

public class Test {
	public String getString(){
		return "HALLO";
	}

}
