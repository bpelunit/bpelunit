package org.bpelunit.framework.coverage.annotation.tools.bpelxmltools.exprlang;

public class XqueryLanguage extends ExpressionLanguage {

	@Override
	public String concat(String[] strings) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLanguageSpecification() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String negateExpression(String expression) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String valueOf(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
