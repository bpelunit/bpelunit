/**
 * This file belongs to the BPELUnit utility and Eclipse plugin set. See enclosed
 * license file for more information.
 * 
 */
package org.bpelunit.framework.exception;

import javax.xml.soap.SOAPException;

/**
 * An exception while constructing or deconstructing a SOAP Message.
 * 
 * @version $Id: SOAPEncodingException.java 81 2007-06-03 10:07:37Z asalnikow $
 * @author Philip Mayer
 * 
 */
public class SOAPEncodingException extends BPELUnitException {

	private static final long serialVersionUID= 3619498013207248294L;

	public SOAPEncodingException(String message) {
		super(message);
	}

	public SOAPEncodingException(String message, SOAPException e) {
		super(message, e);
	}

}
