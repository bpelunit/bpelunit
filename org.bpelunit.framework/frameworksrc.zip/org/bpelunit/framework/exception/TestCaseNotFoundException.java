/**
 * This file belongs to the BPELUnit utility and Eclipse plugin set. See enclosed
 * license file for more information.
 * 
 */
package org.bpelunit.framework.exception;

/**
 * 
 * Thrown if the test suite is instructed to only run certain test cases, but the test cases are
 * unknown.
 * 
 * @version $Id: TestCaseNotFoundException.java 81 2007-06-03 10:07:37Z asalnikow $
 * @author Philip Mayer
 * 
 */
public class TestCaseNotFoundException extends BPELUnitException {

	private static final long serialVersionUID= 4339387409248483260L;

	public TestCaseNotFoundException(String message) {
		super(message);
	}

}
